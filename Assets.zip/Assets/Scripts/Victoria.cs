using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.VisualScripting;

public class Victoria : MonoBehaviour
{

    private void Update()
    {
       
    }
    private void OnTriggerEnter2D(Collider2D Victoria)
    {
        if(Victoria.tag == "Player")
        {
            Time.timeScale = 0;
        }

    }



}
