using System.Collections;
using UnityEngine;

public class Jugador : MonoBehaviour
{
    //movimiento en vertical y horizontal
    private float movimientoEjeX;
    private float movimientoEjeY;
    //Velocidad del personaje
    public float velocidadMovimiento = 5.0f;
    //Para el aturdimiento
    private bool aturdido = false;
    // Cuanto dura el aturdimiento 
    private float tiempoAturdimiento = 2.0f;

    private Animator cambioColor;


    private void Start()
    {
        cambioColor = GetComponent<Animator>();
    }

    void Update()
    {
        if (aturdido == false)
        {
            movimientoEjeY = Input.GetAxis("Vertical") * Time.deltaTime * velocidadMovimiento;
            movimientoEjeX = Input.GetAxis("Horizontal") * Time.deltaTime * velocidadMovimiento;
            transform.Translate(movimientoEjeX, movimientoEjeY, 0);
            
        }
    
          

    }

    public void OnCollisionEnter2D(Collision2D col)
    {

        StartCoroutine(DesactivarAturdimiento());
    }

    IEnumerator DesactivarAturdimiento()
    {
        aturdido = true;
        if(aturdido == true)
        {
            cambioColor.SetBool("salida", true);
         }
        yield return new WaitForSeconds(tiempoAturdimiento);
        aturdido = false;
        cambioColor.SetBool("salida", false);

    }
}

