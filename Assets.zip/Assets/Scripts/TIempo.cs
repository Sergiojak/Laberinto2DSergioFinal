using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TIempo : MonoBehaviour
{
    float tiempo = 120f;
    private TextMeshProUGUI temporalizador;
    void Start()
    {
        temporalizador = GetComponent<TextMeshProUGUI>();
    }

    void Update()
    {
        tiempo = tiempo - Time.deltaTime;
        temporalizador.text = tiempo.ToString("0");
       if(tiempo <= 0)
        { 
            Time.timeScale = 0;
        }
    }
}
